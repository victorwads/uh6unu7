package br.com.victorwads.workshoplifecycle

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.println(Log.ASSERT,"WORKSHOP", "onCreated")
    }

    override fun onStart() {
        super.onStart()
        Log.println(Log.ASSERT,"WORKSHOP", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.println(Log.ASSERT,"WORKSHOP", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.println(Log.ASSERT,"WORKSHOP", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.println(Log.ASSERT,"WORKSHOP", "onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.println(Log.ASSERT,"WORKSHOP", "onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.println(Log.ASSERT,"WORKSHOP", "onDestroy")
    }

}
