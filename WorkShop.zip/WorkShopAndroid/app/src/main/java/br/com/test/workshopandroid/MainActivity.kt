package br.com.test.workshopandroid

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

class MainActivity : AppCompatActivity() {

    lateinit var button: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.println(Log.ASSERT,"Workshop", "onCreate")

        setContentView(R.layout.activity_main)
        button = findViewById(R.id.btn_proxima)
        button.setOnClickListener { openCalc() }
    }

    private fun openCalc() {
        val intent = Intent(this, Calc::class.java)
        startActivity(intent)
    }

    override fun onStart() {
        super.onStart()
        Log.println(Log.ASSERT,"Workshop", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.println(Log.ASSERT,"Workshop", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.println(Log.ASSERT,"Workshop", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.println(Log.ASSERT,"Workshop", "onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.println(Log.ASSERT,"Workshop", "onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.println(Log.ASSERT,"Workshop", "onDestroy")
    }

}
